/**
 * background.ts (MV3 service worker)
 *
 * TypeScriptで書き、latexExtraction.tsのextractLatexFromSelection()をユニットテスト済みの
 * まま利用する(以前はpublic/background.jsとして素のJSで直接書いており、DOM抽出ロジックを
 * テストできなかった。v4.0.0でsrc/配下のビルドパイプラインに移した)。
 */
import { extractLatexFromSelection } from './latexExtraction';

const QUICK_POPUP_PREFILL_KEY = 'quickPopupPrefill';
const MAIN_PAGE_PREFILL_KEY = 'mainPagePrefill';
const QUICK_MENU_ID = 'equashare-quick';
const FULL_MENU_ID = 'equashare-full';

// ---------------------------------------------------------------------------
// ツールバーアイコン: 既存の「Equashare」タブがあればそれをフォーカスし、無ければ
// 新しいタブとしてindex.htmlを開く。
// ---------------------------------------------------------------------------

async function openOrFocusMainTab(): Promise<chrome.tabs.Tab | undefined> {
  const url = chrome.runtime.getURL('index.html');
  const existing = await chrome.tabs.query({ url });
  const tab = existing[0];
  if (tab?.id !== undefined) {
    await chrome.tabs.update(tab.id, { active: true });
    if (tab.windowId !== undefined) {
      await chrome.windows.update(tab.windowId, { focused: true });
    }
    return tab;
  }
  return chrome.tabs.create({ url });
}

chrome.action.onClicked.addListener(() => {
  void openOrFocusMainTab();
});

// ---------------------------------------------------------------------------
// グローバルホットキー(既定Ctrl+Shift+E)→ 簡易入力ポップアップ
// ---------------------------------------------------------------------------
// default_popupを常時manifestに固定すると、ツールバークリックがポップアップを開くように
// なってしまい上のonClickedが発火しなくなる(Chromeの仕様)。そのため「ホットキーが
// 押された時だけ一時的にpopupを設定してからopenPopup()し、開いた直後に空へ戻す」。
//
// このコマンドはmanifest.json側で"global": trueにしていない(Chromeの制約上、globalスコープの
// ショートカットはCtrl+Shift+[0-9]の数字キーしか使えず、既定のCtrl+Shift+Eを維持できないため)。
// そのためこのホットキーは「ブラウザにフォーカスがある間だけ」反応する。

async function openQuickPopup(): Promise<void> {
  try {
    await chrome.action.setPopup({ popup: 'popup.html' });
    await chrome.action.openPopup();
  } finally {
    await chrome.action.setPopup({ popup: '' });
  }
}

/** アクティブタブで選択されているテキストから、可能ならLaTeXソースを読み取る。
 * chrome://等のスクリプト注入が許可されないページや、アクティブタブが取得できない
 * 場合は空文字を返す(致命的にはしない=空欄のポップアップ/タブを開く方にフォールバックする)。 */
async function readSelectionFromActiveTab(): Promise<string> {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id === undefined) return '';
    // world: 'MAIN' が必須。既定の'ISOLATED'ワールドではページ自身が定義した
    // window.MathJax が見えず(別のJS実行コンテキストのため)、latexExtraction.ts側の
    // 主戦略(MathJax内部APIからの直接取得)が常に空振りしてDOMフォールバックへ
    // 落ちてしまう。
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: 'MAIN',
      func: extractLatexFromSelection,
    });
    const value = results[0]?.result;
    return typeof value === 'string' ? value : '';
  } catch {
    return '';
  }
}

chrome.commands.onCommand.addListener((command) => {
  if (command !== 'open-quick-popup') return;
  void (async () => {
    const text = await readSelectionFromActiveTab();
    if (text) {
      await chrome.storage.session.set({ [QUICK_POPUP_PREFILL_KEY]: text });
    }
    await openQuickPopup();
  })();
});

// ---------------------------------------------------------------------------
// Webページ上でのLaTeX選択 → 右クリックメニュー
// ---------------------------------------------------------------------------
// info.selectionText(ブラウザが返す「見た目のテキスト」)はMathJaxの描画済みグリフを
// そのまま拾ってしまい ^2 や \sqrt 等の構文が失われるため使わない。代わりに
// chrome.scripting.executeScript でページ内のDOMから直接LaTeXソースを取り直す
// (extractLatexFromSelection、ホットキーの場合と全く同じロジック)。
// なお、MathJax自身が数式上への右クリックに独自メニューを出す設定の場合、ページの
// contextmenuイベントがpreventDefault()されてブラウザの標準メニュー(と、そこに載っている
// この拡張機能のメニュー項目)自体が表示されないことがある。これは拡張機能側では制御でき
// ない仕様上の制約であり、その場合はCtrl+Shift+Eの方を使えば同じ抽出ロジックで代替できる。

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: QUICK_MENU_ID,
    title: 'Equashareで簡易表示',
    contexts: ['selection'],
  });
  chrome.contextMenus.create({
    id: FULL_MENU_ID,
    title: 'Equashareで表示',
    contexts: ['selection'],
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  void (async () => {
    let text = '';
    if (tab?.id !== undefined) {
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          world: 'MAIN', // 理由はreadSelectionFromActiveTab()のコメント参照。
          func: extractLatexFromSelection,
        });
        const value = results[0]?.result;
        if (typeof value === 'string') text = value;
      } catch {
        // スクリプト注入が許可されないページ(chrome://等)では諦める。
      }
    }
    // DOM抽出が(未対応ページ等で)失敗した場合の最終フォールバックとして、
    // ブラウザが渡してくる「見たままのテキスト」だけは使う(空文字よりまし)。
    if (!text) text = info.selectionText ?? '';
    if (!text) return;

    if (info.menuItemId === QUICK_MENU_ID) {
      await chrome.storage.session.set({ [QUICK_POPUP_PREFILL_KEY]: text });
      await openQuickPopup();
      return;
    }

    if (info.menuItemId === FULL_MENU_ID) {
      const url = chrome.runtime.getURL('index.html');
      const existing = await chrome.tabs.query({ url });
      if (existing.length > 0 && existing[0].id !== undefined) {
        // 既に開いているタブがある場合は、新しいタブを増やさずstorage.session経由で反映する
        // (main.ts側のchrome.storage.onChangedリスナーが拾う)。
        await chrome.storage.session.set({ [MAIN_PAGE_PREFILL_KEY]: text });
        await openOrFocusMainTab();
      } else {
        // 新規タブの場合はURLのクエリparamで渡す(タブ読み込みと同時に反映されるため
        // storage経由のようなレースコンディションが起きない)。
        await chrome.tabs.create({ url: `${url}?prefill=${encodeURIComponent(text)}` });
      }
    }
  })();
});
